package GUI_PROJECT_2;

/**
 * Used to enumerate colors in labels
 */
public enum Colors{
    GREEN, ORANGE, RED, BLACK, WHITE, YELLOW, BLUE
}
