package GUI_PROJECT_2;

public enum FileStatus {
    MODIFIED, NEW, SAVED, OPENED, CREATED
}
